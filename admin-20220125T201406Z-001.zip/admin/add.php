<?php
include_once("includes/header.php");
include_once("includes/dbconn.php");


if (isset($_POST['btn_student'])) {
      $user=$_POST['user'];
      $number=$_POST['number'];
      $address=$_POST['address'];
      $date=$_POST['date'];
      $university_name=$_POST['university_name'];
      $university_number=$_POST['university_number'];
      $university_email=$_POST['university_email'];
      $university_pass=$_POST['university_pass'];
      $Specialization=$_POST['Specialization'];
      $avg=$_POST['avg'];
      $phone=$_POST['phone'];

      $query="INSERT INTO signup(`student_name`, `number`, `address` , `date`, `university_name`, `university_number`, `university_email`, `university_pass`, `Specialization` , `university_average`, `phone`)VALUES('$user' , '$number' , '$address' , '$date' , '$university_name' , '$university_number' , '$university_email' , '$university_pass', '$Specialization' , '$avg' , '$phone') ";
      mysqli_query($conn,$query);
}
?>

            <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header"> </h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-10">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                               التقديم للمنحة
                    </div>
                        <div class="panel-body">
                        <div class="table-responsive">
                                      <form action="#" method="post">
                                                <div class="form-group">
                                                    <label for="">اسم الطالب :</label>
                                                    <input class="form-control" type="text" value="" name="user" placehorder="اسم الطالب/ة">
                                                 </div>
                                                 <div class="form-group">
                                                    <label for=""> الرقم الوطني : </label>
                                                    <input class="form-control" type="text" value="" name="number"  placehorder=" الرقم الوطني">
                                                 </div>
                                                 <div class="form-group">
                                                    <label for="">مكان الأقامة : </label>
                                                    <input class="form-control" type="text" value="" name="address"  placehorder="مكان الاقامة">
                                                 </div>
                                                 
                                                 <div class="form-group">
                                                    <label for=""> تاريخ الميلاد  :</label>
                                                    <input class="form-control" type="date" value="" name="date"  placehorder="تاريخ الميلاد">
                                                 </div>
                                                 <div class="form-group">
                                                    <label for=""> اسم  الجامعة  :</label>
                                                    <input class="form-control" type="text" value="" name="university_name" placehorder="اسم الجامعة">
                                                 </div>
                                                 <div class="form-group">
                                                    <label for="">الرقم الجامعي : </label>
                                                    <input class="form-control" type="text" value="" name="university_number" placehorder="الرقم الجامعي">
                                                 </div>
                                                 <div class="form-group">
                                                    <label for="">الاميل الجامعي : </label>
                                                    <input class="form-control" type="text" value="" name="university_email" placehorder="الأميل الجامعي">
                                                 </div>
                                                 <div class="form-group">
                                                    <label for=""> كلمة المرور : </label>
                                                    <input class="form-control" type="text" value="" name="university_pass" placehorder="كلمة المرور">
                                                 </div>
                                                 <div class="form-group">
                                                    <label for="">التخصص :</label>
                                                    <input class="form-control" type="text" value="" name="Specialization" placehorder="التخصص">
                                                 </div>
                                                 <div class="form-group">
                                                    <label for="">المعدل الجامعي :</label>
                                                    <input class="form-control" type="text" value="" name="avg" placehorder="المعدل الجامعي ">
                                                 </div>
                                                 <div class="form-group">
                                                    <label for="">الهاتف  :</label>
                                                    <input class="form-control" type="text" value="" name="phone" placehorder=" الرقم الهاتف ">
                                                 </div>                                           
                        <div class="">
                        <center>
                        <button type="submit" class="btn btn-primary" name="btn_student">أضافة الطلب </button> 
                        </center>
                        </div>
                                      </form>
                    </div>
                    </div>

                    </div>
                </div>
                </div>
                </div>
    <?php
include_once("includes/footer.php");    ?>