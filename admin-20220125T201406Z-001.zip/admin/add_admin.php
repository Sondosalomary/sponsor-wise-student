<?php
include_once("includes/header.php");
include_once("includes/dbconn.php");

error_reporting();
if (isset($_POST['btn_admin'])) {
      $admin_name=$_POST['fullname'];
      $admin_email=$_POST['email'];
      $admin_password=$_POST['password'];
      $admin_phone=$_POST['phone'];
      $query="INSERT INTO admin(`admin_fullname`, `admin_email`, `admin_password` , `admin_phone`)VALUES('$admin_name' , '$admin_email' , '$admin_password' , '$admin_phone')";
      mysqli_query($conn,$query);
}
?>
            <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header"> إضافة آدمن جديد </h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-10">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            إضافة آدمن جديد 
                    </div>
                        <div class="panel-body">
                        <div class="table-responsive">
                                      <form action="#" method="post" novalidate="novalidate" enctype="multipart/form-data">
                                                <div class="form-group">
                                                    <label for="">الإسم  :</label>
                                                    <input class="form-control" type="text" value="" name="fullname" placehorder="الإسم">
                                                 </div>
                                                 <div class="form-group">
                                                    <label for="">  البريد الإلكتروني : </label>
                                                    <input class="form-control" type="text" value="" name="email"  placehorder=" البريد الإلكتروني ">
                                                 </div>
                                                 <div class="form-group">
                                                    <label for=""> كلمة المرور : </label>
                                                    <input class="form-control" type="text" value="" name="password"  placehorder=" كلمة المرور">
                                                 </div>
                                                 <div class="form-group">
                                                    <label for="">  الهاتف : </label>
                                                    <input class="form-control" type="text" value="" name="phone"  placehorder="  الهاتف">
                                                 </div>                                                        
                        <div class="">
                        <center>
                        <button type="submit" class="btn btn-primary" name="btn_admin">إضافة آدمن </button> 
                        </center>
                        </div>
                                      </form>
                    </div>
                    </div>

                    </div>
                </div>
                </div>
                </div>
    <?php
include_once("includes/footer.php");    ?>