<?php

include_once("includes/dbconn.php");
$id=$_GET['delete_sponsor'];
$query="delete  from sponsorenew where sponsor_id=$id";
mysqli_query($conn,$query);
header("location:viewsponsor.php");
?>