<?php

include_once("includes/dbconn.php");

$id=$_GET['delete_id'];
$query="delete from signup where signup_id=$id";
mysqli_query($conn,$query);
header("location:index.php");




?>