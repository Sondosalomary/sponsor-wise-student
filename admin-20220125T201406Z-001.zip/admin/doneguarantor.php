<?php
include_once("includes/header.php");
include_once("includes/dbconn.php");
error_reporting();
$query="select * from signup JOIN grantt JOIN sponsorenew where grantt.signup_id=signup.signup_id AND grantt.sponsor_id=sponsorenew.sponsor_id";

$result=mysqli_query($conn,$query);

while ($row=mysqli_fetch_assoc($result)) {
if ($row['status']!='part' AND $row['status']!='null') {
?>



            <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">     </h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-8">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                                اسم الطالب/ة  : <th> <?php echo $row['student_name'];?></th>

                        </div>
                        <div class="panel-body">`
                        <div class="row">
                            <div class="col-lg-9">
                                <table class="table">
                                    <thead >
                                        <tr class="success">
                                            <th>اسم الطالب/ة: </th>
                                            <th> <?php echo $row['student_name'];?></th>
                                            
                                            <th> اسم الكفيل : </th>
                                        <th> <?php echo $row['sponsor_name'];?></th>
                                              

                                    </tr>
                                    </thead>
                                </table>
                                
                               
                                </div>

                                <div class="col-lg-12">
                                <table class="table">
                                    <thead>
                                        <tr class="danger">
                                        <th><h3>حالة الطلب</h3></th>
                                        <th>
                                        <?php 
                                                if($row['status']=='part') {
                                                    
                                                

                                                    echo"<h4>  تم منحك بنجاح نصف المبلغ المطلوب </h4>";

                                                }elseif($row['status']=='one') {
                                                    echo"<h4> تم قبولك بنجاح في منحة لفصل دراسي واحد  </h4>";
                                                }elseif ($row['status']=='tow') {
                                                    echo"<h4> تم قبولك بنجاح في منحة لفصلين دراسيين   </h4>";

                                                }elseif($row['status']=='full') {
                                                    echo"<h4> تم قبولك بنجاح في منحة لطول الفترة الدراسية    </h4>";
 }
 ?>
                                                    </th>                                           
                                    </tr>
                                    </thead>
                                </table>
                                </div>

                                <div class="col-lg-3">
                                <table class="table">
                                    <thead>
                                        <tr class="danger">            
                                    </tr>
                                    </thead>
                                </table>
                                </div>        
                </div>
                
                        </div>
                        <div class="panel-footer">
                        </div>
                    </div>
                </div>
                </div>
                </div>
                <?php }} ?>
    <?php
include_once("includes/footer.php");    ?>
