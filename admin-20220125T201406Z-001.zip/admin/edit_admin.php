<?php
include_once("includes/header.php");
include_once("includes/dbconn.php");

error_reporting();

$id=$_GET['edit_id'];

if (isset($_POST['btn_admin'])) {
      $admin_name=$_POST['fullname'];
      $admin_email=$_POST['email'];
      $admin_password=$_POST['password'];
      $admin_phone=$_POST['phone'];
      $admin_image=$_FILES['image']['name'];
      $tmp_name=$_FILES['image']['tmp_name'];
      $path='images/';
      move_uploaded_file($tmp_name , $path.$admin_image);
     

      $query="update admin set admin_fullname ='$admin_name' , admin_email ='$admin_email', 
                                admin_password='$admin_password' , admin_phone ='$admin_phone' , admin_image='$admin_image'
                                where admin_id=$id";
      $result=mysqli_query($conn,$query);
      if ($result) {
          header("location:view_admin.php");
      }
    
}
  
$query="select * from admin where admin_id=$id";
$result=mysqli_query($conn,$query);
$row=mysqli_fetch_assoc($result);
?>

            <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header"> إضافة ادمن جديد </h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-10">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            أضافة ادمن جديد 
                    </div>
                        <div class="panel-body">
                        <div class="table-responsive">
                                      <form action="#" method="post" novalidate="novalidate" enctype="multipart/form-data">
                                                <div class="form-group">
                                                    <label for="">الاسم  :</label>
                                                    <input class="form-control" type="text" value="<?php echo $row['admin_fullname'] ?>" name="fullname" placehorder="الاسم">
                                                 </div>
                                                 <div class="form-group">
                                                    <label for="">  الإيميل : </label>
                                                    <input class="form-control" type="text" value="<?php echo $row['admin_email'] ?>" name="email"  placehorder=" الإميل ">
                                                 </div>
                                                 <div class="form-group">
                                                    <label for=""> كلمة المرور : </label>
                                                    <input class="form-control" type="text" value="<?php echo $row['admin_password'] ?>" name="password"  placehorder=" كلمة المرور">
                                                 </div>
                                                 <div class="form-group">
                                                    <label for="">  الهاتف : </label>
                                                    <input class="form-control" type="text" value="<?php echo $row['admin_phone'] ?>" name="phone"  placehorder="  الهاتف">
                                                 </div>
                                                
                                         
                                              
                                          
                                               

                                            
                        <div class="">
                        <center>
                        <button type="submit" class="btn btn-primary" name="btn_admin">حفظ التعديلات   </button> 
                        </center>
                        </div>


                                      </form>
                    </div>
                    </div>

                    </div>
                </div>
                </div>
                </div>
    <?php
include_once("includes/footer.php");    ?>