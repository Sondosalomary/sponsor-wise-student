<?php
include_once("includes/header.php");
include_once("includes/dbconn.php");
error_reporting();
?>

            <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header"> </h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                         سجل الطلبة
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table">
                                        <thead>

                                                <tr>
                                                    <th>اسم الطالب /ة</th>
                                                    <th>الرقم الوطني</th>
                                                    <th> مكان الاقامة</th>
                                                    <th>تاريخ الميلاد</th>
                                                    <th> اسم الجامعة </th>
                                                    <th>الرقم الجامعي</th>
                                                    <th>الايميل الجامعي</th>
                                                    <th>كلمة المرور </th>
                                                    <th>التخصص</th>
                                                    <th>المعدل الجامعي</th>
                                                    <th> الهاتف</th>
                                                    <th>تعديل البيانات </th>
                                                    <th>حذف البيانات </th>
                                                    
                                                </tr>

                                        </thead>

                            <?php
                                        $query="select * from signup";
                                        $result=mysqli_query($conn,$query);
                                        while ($row=mysqli_fetch_assoc($result)) {
                                            
                                        
                              
                              ?>

  

                                                <tr>
                                                    <th> <?php echo $row['student_name'];?></th>
                                                    <th> <?php echo $row['number'];?></th>
                                                    <th> <?php echo $row['address'];?></th>
                                                    <th> <?php echo $row['date'];?></th>
                                                    <th> <?php echo $row['university_name'];?></th>
                                                    <th> <?php echo $row['university_number'];?></th>
                                                    <th> <?php echo $row['university_email'];?></th>
                                                    <th> <?php echo $row['university_pass'];?></th>
                                                    <th> <?php echo $row['Specialization'];?></th>
                                                    <th> <?php echo $row['university_average'];?></th>
                                                    <th> <?php echo $row['phone'];?></th>
                                                    <th><a href="edit_student.php?edite_id=<?php echo $row['signup_id'] ?>"><button type="submit" class="btn btn-primary"> تعديل البيانات  </button></a> </th>
                                                    <th><a href="delete_student.php?delete_id=<?php echo $row['signup_id'] ?>"><button type="submit" class="btn btn-danger"> حذف البيانات  </button></a> </th>


                                                </tr>
                                                <?php } ?>
                                        </table>

                    </div>
                        <div class="panel-footer">
                            <a href="add.php"><button type="submit" class="btn btn-primary">إضافة طلاب </button>  </a>
                        </div>
                    </div>
                </div>
                </div>
                </div>
                </div>
                </div>
                <?php
include_once("includes/footer.php"); 
   ?>