<?php

include_once("includes/dbconn.php");
include_once("");
session_start();
session_unset();
session_destroy();

header("location:login.php");
?>