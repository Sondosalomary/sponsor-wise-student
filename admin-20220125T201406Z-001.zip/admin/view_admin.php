<?php
include_once("includes/header.php");
include_once("includes/dbconn.php");
?>

            <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header"> </h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            قسم معلومات  المسؤولين 
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table">
                                        <thead>

                                                <tr>
                                                <th>اسم المسؤول </th>
                                                <th> البريد الإلكتروني   </th>
                                                <th>الهاتف   </th>
                                                <th>   </th>
                                                <th> حذف البيانات   </th> 
                                                <th>  تعديل البيانات</th>
                                                   
                                                </tr>
                                            
                                        </thead>
                              <?php
                                        $query="select * from admin";
                                        $result=mysqli_query($conn,$query);
                                        while ($row=mysqli_fetch_assoc($result)) {
                                            
                                        
                              
                              ?>
                                                <tr>
                                                <th> <?php echo $row['admin_fullname']; ?> </th>
                                                <th> <?php echo $row['admin_email']; ?></th>
                                                <th>  <?php echo $row['admin_phone']; ?> </th>
                                                <th> <img src="../images/<?php echo $row['admin_image']; ?>" alt="" srcset=""> </th>
                                                <th><a href="edit_admin.php?edit_id=<?php echo $row['admin_id']; ?>"><button type="submit" class="btn btn-primary"> تعديل البيانات  </button></a> </th>
                                                <th><a href="delete_admin.php?delete_id=<?php echo $row['admin_id']; ?>"><button type="submit" class="btn btn-danger"> حذف البيانات  </button></a> </th>


                                                    
                                                </tr>
                                                <?php }?>
                                        </table>

                    </div>
                        <div class="panel-footer">
                            <a href="add_admin.php"><button type="submit" class="btn btn-primary">إضافة مسؤول </button>  </a>
                        </div>
                    </div>
                </div>
                </div>
                </div>
                </div>
                </div>
    <?php
include_once("includes/footer.php");    ?>