<?php
include_once("includes/header.php");
include_once("includes/dbconn.php");
?>

            <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header"> </h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            قسم معلومات الكفلاء في النظام
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table">
                                        <thead>

                                                <tr>
                                                <th>اسم الكفيل </th>
                                                <th>الرقم الوطني  </th>
                                                <th>مكان الإقامة  </th>
                                                <th>البريد الإلكتروني   </th>
                                                <th> تاريخ الميلاد  </th> 
                                                <th>الهاتف   </th>
                                                <th> حذف الكفيل</th>
                                                   
                                                </tr>
                                            
                                        </thead>
                              <?php
                                        $query="select * from sponsorenew";
                                        $result=mysqli_query($conn,$query);
                                        while ($row=mysqli_fetch_assoc($result)) {
                                            
                                        
                              
                              ?>
                                                <tr>
                                                <th> <?php echo $row['sponsor_name']; ?> </th>
                                                <th> <?php echo $row['sponsor_nummber']; ?></th>
                                                <th>  <?php echo $row['sponsor_residence']; ?> </th>
                                                <th>  <?php echo $row['sponsor_email']; ?> </th>
                                                <th>  <?php echo $row['sponsor_date']; ?> </th>
                                                <th><?php echo $row['sponsor_phone']; ?></th>
                                                    <th><a href="delete_sponsor.php?delete_sponsor=<?php echo $row['sponsor_id']; ?>"><button type="submit" class="btn btn-danger"> حذف البيانات  </button></a> </th>

                                                    
                                                </tr>
                                                <?php }?>
                                        </table>

                    </div>
                        <div class="panel-footer">
                        </div>
                    </div>
                </div>
                </div>
                </div>
                </div>
                </div>
    <?php
include_once("includes/footer.php");    ?>