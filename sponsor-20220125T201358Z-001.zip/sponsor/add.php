
<?php

include_once("includes/dbconn.php");

?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Elearning System</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/rtl/bootstrap.min.css" rel="stylesheet">
    
    <!-- not use this in ltr -->
    <link href="css/rtl/bootstrap.rtl.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="css/plugins/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Timeline CSS -->
    <link href="css/plugins/timeline.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/rtl/sb-admin-2.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="css/plugins/morris.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="css/font-awesome/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>

<body>
<?php
if (isset($_POST['sponsor_btn'])) {
    $namee=$_POST['user'];
    $nummber1=$_POST['nummber1'];
    $address=$_POST['address'];
    $date=$_POST['date'];
    $phone=$_POST['phone'];
    $email=$_POST['email'];
    $pass=$_POST['pass'];

    $query="INSERT INTO sponsorenew(sponsor_name , sponsor_nummber, sponsor_residence, sponsor_date , sponsor_phone , sponsor_email , sponsor_password)VALUES('$namee' , '$nummber1' , '$address' , '$date' , '$phone' , '$email' , '$pass')";
    mysqli_query($conn,$query);



} 


?>
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="login-panel panel panel-primary">
                    <div class="panel-heading">
                        <h3 class="panel-title" style="text-align:center;">تسجيل مستخدم جديد </h3>
                    </div>
                    <div class="panel-body">
                    <form action="#" method="POST">
                        <fieldset>
                                                <div class="form-group">
                                                    <label for="">الاسم  :</label>
                                                    <input class="form-control" type="text" name="user" value="" placehorder="الاسم">
                                                 </div>
                                                 <div class="form-group">
                                                    <label for=""> الرقم الوطني : </label>
                                                    <input class="form-control" type="text" name="nummber1" value="" placehorder=" الرقم الوطني">
                                                 </div>
                                                 <div class="form-group">
                                                    <label for="">مكان الإقامة : </label>
                                                    <input class="form-control" type="text" name="address" value="" placehorder="مكان الاقامة">
                                                 </div>
                                                 
                                                 <div class="form-group">
                                                    <label for=""> تاريخ الميلاد  :</label>
                                                    <input class="form-control" type="date" name="date" value="" placehorder="تاريخ الميلاد">
                                                 </div>
                                                 <div class="form-group">
                                                    <label for="">الهاتف  : </label>
                                                    <input class="form-control" type="text" name="phone" value="" placehorder="الهاتف ">
                                                 </div>
                                                 <div class="form-group">
                                                    <label for="">البريد الإلكتروني : </label>
                                                    <input class="form-control" type="text"  name="email" value="" placehorder="الأميل ">
                                                 </div>
                                                
                                                 <div class="form-group">
                                                    <label for=""> كلمة المرور :</label>
                                                    <input class="form-control" type="text" name="pass" value="" placehorder="كلمة المرور  ">
                                                 </div>

                                                 <div>
                                                <button id="payment-button" name="sponsor_btn" type="submit" class="btn btn-lg btn-info btn-block">
                                                  التسجيل
                                                </button>
                                            </div

                        </fieldset>
                                      </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- jQuery Version 1.11.0 -->
    <script src="js/jquery-1.11.0.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="js/metisMenu/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="js/sb-admin-2.js"></script>

</body>

</html>
