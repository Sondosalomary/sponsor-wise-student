<?php
include_once("includes/header.php");
include_once("includes/dbconn.php");
$query="select * from signup JOIN grantt where  signup.signup_id=grantt.signup_id AND  grantt.status=('part' or 'null')";

$result=mysqli_query($conn,$query);

while ($row=mysqli_fetch_array($result)) {
  if ($row['status']=='part' OR $row['status']=='null' ) {

?>



            <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header"></h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-8">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                                اسم الطالب/ة  : <th> <?php echo $row['student_name'];?></th>

                        </div>
                        <div class="panel-body">
                        <div class="row">
                            <div class="col-lg-9">
                                <table class="table">
                                    <thead >
                                        <tr class="success">
                                            <th>اسم الطالب/ة: </th>
                                            <th> <?php echo $row['student_name'];?></th>
                                            
                                            <th>مكان الإقامة : </th>
                                        <th> <?php echo $row['address'];?></th>
                                              

                                    </tr>
                                    </thead>
                                </table>
                                
                               
                                </div>

                                <div class="col-lg-9">
                                <table class="table">
                                    <thead>
                                        <tr class="info">
                                        
                                        <th> الجامعة : </th>
                                        <th> <?php echo $row['university_name'];?></th>
                                        <th>الرقم الجامعي : </th>
                                        <th> <?php echo $row['university_number'];?></th>
                                           
                                    </tr>
                                    </thead>
                                </table>
                                </div>

                                <div class="col-lg-9">
                                <table class="table">
                                    <thead>
                                        <tr class="info">
                                        <th> التخصص : </th>
                                            <th> <?php echo $row['Specialization'];?></th>
                                            <th>المعدل الجامعي : </th>
                                        <th> <?php echo $row['university_average'];?></th>

                                        <th>قيمة المبلغ كامل :</th>
                                        <th> <?php echo $row['grant_full_price'];?></th>
      
    </tr>
                                    </thead>
                                </table>
                                </div>
                                <div class="col-lg-9">
                                <table class="table">
                                    <thead>
                                        <tr class="info">
                                      <th>الشروحات:</th>
                                        <th><?php echo $row['descr']; ?></th>

                                            <th>عدد الساعات:</th>
                                            <th><?php echo $row['number_of_hours']; ?></th>

                                         </tr>
                                    </thead>
                                </table>
                                </div>
                                

                                <div class="col-lg-12">
                                <table class="table">
                                    <thead>
                                        <tr class="danger">
                                        

                                            
                                    </tr>
                                    </thead>
                                </table>
                                </div>
                                <div class="col-lg-3">
                                <table class="table">
                                    <thead>
                                        <tr class="danger">
                                        
                                          
                                    </tr>
                                    </thead>
                                </table>
                                </div>
                                     
                </div>

                        </div>
                        <div class="panel-footer">
                            <?php
                                    if ($row['number_of_hours']<="18") {
                                        echo"<a href='status.php?status_id={$row['grant_id']}"."&status=part'><button class='btn btn-primary'> نصف المنحة </button>  </a>";
                                           echo"<a href='status.php?status_id={$row['grant_id']}"."&status=one'><button class='btn btn-warning'>  منحة فصل دراسي </button>  </a>";
                                    }else {
                                        
                            echo"<a href='status.php?status_id={$row['grant_id']}"."&status=tow'><button class='btn btn-success'> منحة فصلين دراسيين </button>  </a>";
                         
                                    }
                          ?>
                        </div>
                       
                    </div>
                </div>
                </div>
                </div>
                <?php }} ?>
    <?php
include_once("includes/footer.php");    ?>
