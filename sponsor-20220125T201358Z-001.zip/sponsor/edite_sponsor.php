
<?php

include_once("includes/dbconn.php");
include_once("includes/header.php");



?>
 <?php
ob_start();
$edite_id=$_GET['edite_id'];
$query="select * from sponsorenew where sponsor_id = $edite_id";
$result=mysqli_query($conn,$query);
$row=mysqli_fetch_assoc($result);

if (isset($_POST['sponsor_btn'])) {
    $namee=$_POST['user'];
    $nummber1=$_POST['nummber1'];
    $address=$_POST['address'];
    $date=$_POST['date'];
    $phone=$_POST['phone'];
    $email=$_POST['email'];
    $pass=$_POST['pass'];

    $query="update  sponsorenew set sponsor_name='$namee' , sponsor_nummber='$nummber1', 
                                sponsor_residence='$address', sponsor_date='$date' , sponsor_phone ='$phone' ,
                                 sponsor_email ='$email' , sponsor_password='$pass' where sponsor_id=$edite_id";
    $result=mysqli_query($conn,$query);
    if ($result) {
        echo"<script>  window.location.href='index.php'; </script>";
    }


} 

ob_end_flush();
 ?>
 <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header"> تعديل البيانات  </h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            تعديل معلومات الكفيل 
                        </div>
    
                    <div class="panel-body">
                    <form action="#" method="POST">
                        <fieldset>
                                                <div class="form-group">
                                                    <label for="">الإسم  :</label>
                                                    <input class="form-control" type="text" name="user" value="<?php echo $row['sponsor_name'] ?>" placehorder="الاسم">
                                                 </div>
                                                 <div class="form-group">
                                                    <label for=""> الرقم الوطني : </label>
                                                    <input class="form-control" type="text" name="nummber1" value="<?php echo $row['sponsor_nummber'] ?>"  placehorder=" الرقم الوطني">
                                                 </div>
                                                 <div class="form-group">
                                                    <label for="">مكان الإقامة : </label>
                                                    <input class="form-control" type="text" name="address" value="<?php echo $row['sponsor_residence'] ?>"  placehorder="مكان الاقامة">
                                                 </div>
                                                 
                                                 <div class="form-group">
                                                    <label for=""> تاريخ الميلاد  :</label>
                                                    <input class="form-control" type="date" name="date" value="<?php echo $row['sponsor_date'] ?>"  placehorder="تاريخ الميلاد">
                                                 </div>
                                                 <div class="form-group">
                                                    <label for="">الهاتف  : </label>
                                                    <input class="form-control" type="text" name="phone" value="<?php echo $row['sponsor_phone'] ?>"  placehorder="الهاتف ">
                                                 </div>
                                                 <div class="form-group">
                                                    <label for="">البريد الإلكتروني  : </label>
                                                    <input class="form-control" type="text"  name="email" value="<?php echo $row['sponsor_email'] ?>"  placehorder="الأميل ">
                                                 </div>
                                                
                                                 <div class="form-group">
                                                    <label for=""> كلمة المرور :</label>
                                                    <input class="form-control" type="text" name="pass" value="<?php echo $row['sponsor_password'] ?>"  placehorder="كلمة المرور  ">
                                                 </div>

                                                 <div>
                                                <button id="payment-button" name="sponsor_btn" type="submit" class="btn btn-lg btn-primary btn-block">
                                                  حفظ التعديلات
                                                </button>
                                            </div

                        </fieldset>
                                      </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
    </div>
<?php

include_once("includes/footer.php");

?>