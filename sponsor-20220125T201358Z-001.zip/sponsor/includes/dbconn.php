<?php


$conn=mysqli_connect("localhost" , "root" , "" ,"sponsor");
if (!$conn) {
	die("can not founde connection");
}


?>