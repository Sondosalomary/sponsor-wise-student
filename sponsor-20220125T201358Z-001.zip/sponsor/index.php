<?php
include_once("includes/header.php");
include_once("includes/dbconn.php");
?>

            <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header"> </h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            قسم معلومات الكفلاء في النظام
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table">
                                        <thead>

                                                <tr>
                                                <th>اسم الكفيل </th>
                                                <th>الرقم الوطني  </th>
                                                <th>مكان الأقامة  </th>
                                                <th>البريد الإلكتروني   </th>
                                                <th> تاريخ الميلاد  </th> 
                                                <th>الهاتف   </th>
                                                   
                                                </tr>
                                            
                                        </thead>
                              <?php

                                        $sponsor_id=$_SESSION['sponsor_id'];
                                        $query="select * from sponsorenew where sponsor_id=$sponsor_id";
                                        $result=mysqli_query($conn,$query);
                                        $row=mysqli_fetch_assoc($result);
                                        
                              
                              ?>
                                                <tr>
                                                <th> <?php echo $row['sponsor_name']; ?> </th>
                                                <th> <?php echo $row['sponsor_nummber']; ?></th>
                                                <th>  <?php echo $row['sponsor_residence']; ?> </th>
                                                <th>  <?php echo $row['sponsor_email']; ?> </th>
                                                <th>  <?php echo $row['sponsor_date']; ?> </th>
                                                <th><?php echo $row['sponsor_phone']; ?></th>

                                                    
                                                </tr>
                                        </table>

                    </div>
                        <div class="panel-footer">
                            <a href="edite_sponsor.php?edite_id=<?php echo $row['sponsor_id']; ?>"><button type="submit" class="btn btn-primary">تعديل  البيانات </button>  </a>
                        </div>
                    </div>
                </div>
                </div>
                </div>
                </div>
                </div>
    <?php
include_once("includes/footer.php");    ?>