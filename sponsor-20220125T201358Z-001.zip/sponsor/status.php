<?php

include_once("includes/dbconn.php");
session_start();
$id=$_GET['status_id'];
$sponsor_id=$_SESSION['sponsor_id'];

$status=$_GET['status'];

$query="update grantt set status='$status' , sponsor_id='$sponsor_id' where grant_id=$id";

mysqli_query($conn,$query);

header('location:applicants.php');



?>