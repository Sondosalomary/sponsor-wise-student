<?php
    include_once("includes/header.php");
    include_once("includes/dbconn.php");
    $student_id=$_SESSION['signup_id'];
$query="select * from signup where signup_id = $student_id";
$result=mysqli_query($conn ,$query);
$row=mysqli_fetch_assoc($result);

?>
<div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">  معلومات الطالب/ة  </h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                            <div class="col-lg-9">
                                <table class="table">
                                    <thead >
                                        <tr class="success">
                                            <th>اسم الطالب/ة: </th>
                                            <th> <?php echo $row['student_name'];?></th>

                                               <th>الرقم الوطني : </th>
                                               <th> <?php echo $row['number'];?></th>

                                    </tr>
                                    </thead>
                                </table>
                                
                               
                                </div>

                                <div class="col-lg-9">
                                <table class="table">
                                    <thead>
                                        <tr class="info">
                                        <th>مكان الإقامة : </th>
                                        <th> <?php echo $row['address'];?></th>
                                        <th> تاريخ الميلاد : </th> 
                                        <th> <?php echo $row['date'];?></th>
                                    
                                    </tr>
                                    </thead>
                                </table>
                                </div>

                                <div class="col-lg-9">
                                <table class="table">
                                    <thead>
                                        <tr class="info">
                                       

                                            <th> الجامعة : </th>
                                            <th> <?php echo $row['university_name'];?></th>
                                   
                                            <th> الرقم الجامعي : </th>
                                            <th> <?php echo $row['university_number'];?></th>
                                        </tr>
                                    </thead>
                                </table>
                                </div>

                                <div class="col-lg-9">
                                <table class="table">
                                    <thead>
                                        <tr class="danger">
                                        <th>الإيميل الجامعي : </th>

                                        <th> <?php echo $row['university_email'];?></th>

                                            <th> التخصص : </th>


                                            <th> <?php echo $row['Specialization'];?></th>
                                    </tr>
                                    </thead>
                                </table>
                                </div>
                                <div class="col-lg-9">
                                <table class="table">
                                    <thead>
                                        <tr class="danger">
                                        <th>المعدل الجامعي : </th>
                                        <th> <?php echo $row['university_average'];?></th>
                                        <th>الهاتف: </th>
                                        <th> <?php echo $row['phone'];?></th>

                                    </tr>
                                    </thead>
                                </table>
                                </div>
                                     
                </div>
                </div> 
                </div>























<?php
    include_once("includes/footer.php");

?>