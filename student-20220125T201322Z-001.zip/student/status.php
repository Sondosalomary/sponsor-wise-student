<?php
include_once("includes/header.php");
include_once("includes/dbconn.php");
$signup_id=$_SESSION['signup_id'];
$query="select * from grantt INNER JOIN signup ON signup.signup_id=$signup_id AND grantt.signup_id=$signup_id ";
$result=mysqli_query($conn,$query);
$row=mysqli_fetch_assoc($result);

    
?>



            <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">  حالة الطلب</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
          
            <div class="row">
                <div class="col-lg-8">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                                اسم الطالب/ة  : <th> <?php echo $row['student_name'];?></th>

                        </div>
                        <div class="panel-body">
                        <div class="row">
                            <div class="col-lg-9">
                                <table class="table">
                                    <thead >
                                        <tr class="success">
                                            <th>اسم الطالب/ة: </th>
                                            <th> <?php echo $row['student_name'];?></th>
                                            
                                            <th>مكان الإقامة : </th>
                                        <th> <?php echo $row['address'];?></th>
                                              

                                    </tr>
                                    </thead>
                                </table>
                                
                               
                                </div>

                                <div class="col-lg-9">
                                <table class="table">
                                    <thead>
                                        <tr class="info">
                                        
                                        <th> الجامعة : </th>
                                        <th> <?php echo $row['university_name'];?></th>
                                        <th>الرقم الجامعي : </th>
                                        <th> <?php echo $row['university_number'];?></th>
                                           
                                    </tr>
                                    </thead>
                                </table>
                                </div>

                                <div class="col-lg-9">
                                <table class="table">
                                    <thead>
                                        <tr class="info">
                                        <th> التخصص : </th>
                                            <th> <?php echo $row['Specialization'];?></th>
                                            <th>المعدل الجامعي : </th>
                                        <th> <?php echo $row['university_average'];?></th>

                                        <th>قيمة المبلغ كامل :</th>
                                        <th> <?php echo $row['grant_full_price'];?></th>
      
    </tr>
                                    </thead>
                                </table>
                                </div>
                                <div class="col-lg-9">
                                <table class="table">
                                    <thead>
                                        <tr class="info">
                                      <th>الشروحات:</th>
                                        <th><?php echo $row['descr']; ?></th>

                                            <th>عدد الساعات:</th>
                                            <th><?php echo $row['number_of_hours']; ?></th>

                                         </tr>
                                    </thead>
                                </table>
                                </div>
                                <div class="col-lg-9">
                                <table class="table">
                                    <thead>
                                        <tr class="info">
                                      <th>المرفقات:</th>
                                        <th><img src="images/<?php echo $row['files']; ?>" alt="" width="500px"; height="350px";></th>

                                          
                                         </tr>
                                    </thead>
                                </table>
                                </div>
                                

                                <div class="col-lg-12">
                                <table class="table">
                                    <thead>
                                        <tr class="danger">
                                        <th><h3>حالة الطلب</h3></th>
                                        <th>
                                        <?php 
                                                if($row['status']=='null') {
                                                    echo"<h4>قيد الانتظار</h4>";
                                                }elseif($row['status']=='part') {
                                                    
                                                

                                                    echo"<h4>  تم منحك بنجاح نصف المبلغ المطلوب </h4>";

                                                }elseif($row['status']=='one') {
                                                    echo"<h4> تم قبولك بنجاح في منحة لفصل دراسي واحد  </h4>";
                                                }elseif ($row['status']=='tow') {
                                                    echo"<h4> تم قبولك بنجاح في منحة لفصلين دراسيين   </h4>";

                                                }elseif($row['status']=='full') {
                                                    echo"<h4> تم قبولك بنجاح في منحة لطول الفترة الدراسية   </h4>";

                                                }
                                        ?>

                                                    </th>
                                            
                                    </tr>
                                    </thead>
                                </table>
                                </div>
                                <div class="col-lg-3">
                                <table class="table">
                                    <thead>
                                        <tr class="danger">
                                        
                                          
                                    </tr>
                                    </thead>
                                </table>
                                </div>
                                     
                </div>
                
                        </div>
                        <div class="panel-footer">
                        </div>
                    </div>
                </div>
                </div>
                </div>
    <?php
include_once("includes/footer.php");    ?>
