<?php
include_once("includes/header.php");
include_once("includes/dbconn.php");
error_reporting();
$signup_id=$_SESSION['signup_id'];


if (isset($_POST['btn_student'])) {
      $number=$_POST['number'];
      $price=$_POST['number']*$_POST['Specialization']+$_POST['section'];
      $descr=$_POST['descr'];
      $image_name=$_FILES['image']['name'];
      $tmp_name=$_FILES['image']['tmp_name'];
      $path='images/';
      move_uploaded_file($tmp_name , $path.$image_name);
      $query="INSERT INTO grantt(`signup_id`,`descr`, `grant_full_price`, `number_of_hours` , `status` , `files`)VALUES('$signup_id','$descr' , '$price' , '$number' , 'null' , '$image_name')";
      $result=mysqli_query($conn,$query);
     
}
  
 ?>

            <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header"> </h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-10">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                               التقديم للمنحة
                    </div>
                        <div class="panel-body">
                        <div class="table-responsive">
                                      <form action="#" method="post" ovalidate="novalidate" enctype="multipart/form-data">
                                      <div class="form-group">
                                            <label>القسم/التخصص</label>
                                            <select class="form-control" name="Specialization">
                                               <option >اختيار التخصص</option>
                                                <option value="45">علم الحاسوب</option>
                                                <option value="45"> أمن الشبكات </option>
                                                <option value="25">تربية خاصة </option>
                                                <option value="10">الفقه الشافعي</option>
                                                <option value="20">أدارة اعمال</option>
                                                <option value="30">القانون</option>

                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label>نوع الدراسة</label>
                                            <select class="form-control" name="section">
                                                <option >اختيار النوع</option>
                                                <option value="250">الموازي</option>
                                                <option value="125"> التنافس </option>
                                                
                                            </select>
                                        </div>
                                                 <div class="form-group">
                                                    <label for="">  عدد الساعات   </label>
                                                    <input class="form-control" type="text" value="" name="number"  placehorder=" الرقم الوطني" required>
                                                 </div>
                                                 <div class="form-group">
                                                    <label for="">  شروحات سبب التقديم    </label>
                                                    <input class="form-control" type="text" value="" name="descr"  placehorder=" الرقم الوطني" required>
                                                 </div>
                                                 <div class="form-group">
                                                    <label for="">   إضافة مرفق (دفتر عائلة،كشف حساب ، شهادة وفاة بحال كان المعيل متوفي)   </label>
                                                    <input class="form-control" type="file" value="" name="image"  placehorder="File" required>
                                                 </div>

                                            
                        <div class="">
                        <center>
                        <button type="submit" class="btn btn-primary" name="btn_student">تقديم الطلب </button> 
                        </center>
                        </div>


                                      </form>
                    </div>
                    </div>

                    </div>
                </div>
                </div>
                </div>
    <?php
include_once("includes/footer.php");    ?>
